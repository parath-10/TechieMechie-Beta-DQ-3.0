NEXUS demo package

TEMPORARY LOGIN
Email:    demo@nexus.local
Password: Nexus123!

Open index.html, click Login, and authenticate with the credentials above.
Successful login redirects to dashboard.html.

The dashboard is protected by a lightweight browser-side demo session:
- Direct dashboard access without a session redirects to index.html.
- Log out clears the session and returns to index.html.

IMPORTANT:
This is demo-only client-side authentication. The credentials are intentionally
visible in the source and are NOT suitable for production. Replace this with
server-side authentication, secure sessions/JWT, or SSO before deployment.
